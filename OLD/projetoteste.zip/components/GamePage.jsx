import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useGame } from '../hooks/useGame';
import { useFirebaseRanking } from '../hooks/useFirebaseRanking';
import MusicPlayer from './MusicPlayer';
import PreviousSongsList from './PreviousSongsList';
import LiveRanking from './LiveRanking';
import GamificationEffect from './GamificationEffect';
import './GamePage.css';
import './GamificationEffect.css';
import confetti from 'canvas-confetti';

import {
  iniciarSalaSeNaoExistir,
  getSalaAtual,
  ouvirSala,
  avancarMusica,
  reiniciarSalaComLoop,
  tentarLockReinicioRodada,
  liberarLockReinicioRodada
} from '../services/firebaseSalaService';

// Permite chamar reiniciarSalaComLoop do backend via window para sincronização global
if (typeof window !== 'undefined') {
  window.reiniciarSalaComLoop = reiniciarSalaComLoop;
}

export default function GamePage() {
  const [roundEnded, setRoundEnded] = useState(false);
  const [audioContextReady, setAudioContextReady] = useState(false);

  useEffect(() => {
    const enableAudioContext = () => {
      setAudioContextReady(true);
      window.removeEventListener('click', enableAudioContext);
    };

    // Adiciona um listener para detectar a interação do usuário
    window.addEventListener('click', enableAudioContext);

    return () => {
      window.removeEventListener('click', enableAudioContext);
    };
  }, []);

  const playEndSound = () => {
    if (!audioContextReady) {
      console.warn('[GamePage] Áudio não pode ser reproduzido antes da interação do usuário.');
      return;
    }

    const audio = new Audio('/assets/sounds/round-end.mp3'); // Certifique-se de que o arquivo existe
    audio.play().catch((error) => {
      console.error('[GamePage] Erro ao reproduzir som de fim de rodada:', error);
    });
  };

  useEffect(() => {
    const roundDuration = 60000; // Example: 60 seconds
    const timer = setTimeout(() => {
      setRoundEnded(true);
    }, roundDuration);

    return () => clearTimeout(timer);
  }, []);

  // Certifique-se de inicializar salaInfo com um valor padrão
  const [salaInfo, setSalaInfo] = useState({
    playlist: [],
    musicaAtual: 0,
    tempoAtual: 0,
    musicStartTimestamp: null,
  });

  useEffect(() => {
    // Verifique se salaInfo está definido e válido antes de usá-lo
    if (
      salaInfo &&
      Array.isArray(salaInfo.playlist) &&
      typeof salaInfo.musicaAtual === 'number' &&
      salaInfo.musicaAtual >= 15 && // Garante que todas as 15 músicas foram tocadas
      salaInfo.playlist.length >= 15 // Garante que a playlist tem pelo menos 15 músicas
    ) {
      setRoundEnded(true); // Define que a rodada terminou
    } else {
      setRoundEnded(false); // Garante que o popup não apareça em outros casos
    }
  }, [salaInfo]);

  useEffect(() => {
    if (roundEnded) {
      try {
        playEndSound(); // Reproduz o som quando a rodada termina
        setTimeout(() => {
          navigate('/result', { replace: true }); // Redireciona automaticamente para o ranking final
        }, 4000); // Delay de 4 segundos antes de redirecionar
      } catch (error) {
        console.error('[GamePage] Erro ao reproduzir som de fim de rodada:', error);
      }
    }
  }, [roundEnded]);

  const handlePopupClose = () => {
    setRoundEnded(false);
  };

  const {
    nickname,
    points,
    addPoints,
    resetGame,
    setNickname
  } = useGame();

  let displayName = '';
  let displayAvatar = '';
  if (typeof nickname === 'object' && nickname !== null) {
    displayName = nickname.name;
    displayAvatar = nickname.avatar.emoji;
  } else if (typeof nickname === 'string') {
    // Tenta restaurar do localStorage
    const storedName = localStorage.getItem('nickname');
    const storedAvatar = localStorage.getItem('avatar');
    if (storedName && storedAvatar) {
      try {
        const avatarObj = JSON.parse(storedAvatar);
        displayName = storedName;
        displayAvatar = avatarObj.emoji;
        // Atualiza contexto se necessário
        setNickname && setNickname({ name: storedName, avatar: avatarObj });
      } catch {
        displayName = nickname;
        displayAvatar = '';
      }
    } else {
      displayName = nickname;
      displayAvatar = '';
    }
  }

  const [input, setInput] = useState('');
  const [feedback, setFeedback] = useState('');
  const [answered, setAnswered] = useState(false);
  const [currentTimeLeft, setCurrentTimeLeft] = useState(20);
  const [shuffledMusics, setShuffledMusics] = useState([]);
  const [musicEnded, setMusicEnded] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentSongIndex, setCurrentSongIndex] = useState(0);
  const [isSalaInfoReady, setIsSalaInfoReady] = useState(false); // Novo estado para rastrear a inicialização
  const [justEntered, setJustEntered] = useState(false);
  const [refreshRankingTrigger, setRefreshRankingTrigger] = useState(0);
  const [attempts, setAttempts] = useState([]); // Histórico de tentativas

  const navigate = useNavigate();
  const inputRef = useRef(null);
  const hasHandledTimeUp = useRef(false);
  const location = useLocation();
  const fromRanking = location.state?.fromRanking;

  useEffect(() => {
    setInput(''); // Limpa o input ao trocar de música
    setAttempts([]); // Limpa histórico ao trocar de música
    setAnswered(false); // Garante input habilitado IMEDIATEMENTE
    
    // --- RESET DE PONTUAÇÃO AUTOMÁTICO SEMPRE AO ENTRAR NA RODADA ---
    if (salaInfo && salaInfo.musicaAtual === 0 && salaInfo.musicStartTimestamp) {
      const nickKey = typeof nickname === 'object' && nickname !== null ? nickname.name : nickname;
      // Sempre zera os pontos ao entrar na rodada
      localStorage.setItem('points_' + nickKey, '0');
      if (typeof window !== 'undefined' && window.setPoints) {
        window.setPoints(0);
      }
    }
  }, [currentSongIndex, salaInfo, nickname]);

  useEffect(() => {
    if (currentSongIndex === 0) {
      setRefreshRankingTrigger(prev => prev + 1);
    }
  }, [currentSongIndex]);

  useEffect(() => {
    const fetchEIniciarSala = async () => {
      try {
        const playlistId = '13739118261';
        const response = await fetch(`http://localhost:3000/playlist/${playlistId}`);
        if (!response.ok) {
          throw new Error(`Erro ao buscar playlist: ${response.statusText}`);
        }
        const data = await response.json();
        const allTracks = data.tracks.data.filter(track => track.preview);

        await iniciarSalaSeNaoExistir(allTracks);
        const sala = await getSalaAtual();

        setShuffledMusics(sala.playlist || []);
        setCurrentSongIndex(sala.musicaAtual || 0);

        setSalaInfo({
          playlist: sala.playlist || [],
          musicaAtual: sala.musicaAtual || 0,
          tempoAtual: sala.tempoAtual || 0,
          musicStartTimestamp: sala.musicStartTimestamp || null,
        });
        setIsSalaInfoReady(true); // Marca como pronto
      } catch (error) {
        console.error('[GamePage] Erro ao inicializar sala:', error);
      }
    };

    fetchEIniciarSala();
  }, []);

  useEffect(() => {
    if (isSalaInfoReady) {
      ouvirSala((novaSala) => {
        if (!novaSala || !novaSala.playlist) return;

        setShuffledMusics(prev => {
          if (JSON.stringify(prev) !== JSON.stringify(novaSala.playlist)) {
            return novaSala.playlist;
          }
          return prev;
        });

        setCurrentSongIndex(prevIdx => {
          if (prevIdx !== novaSala.musicaAtual) {
            return novaSala.musicaAtual;
          }
          return prevIdx;
        });

        setSalaInfo({
          playlist: novaSala.playlist || [],
          musicaAtual: novaSala.musicaAtual || 0,
          tempoAtual: novaSala.tempoAtual || 0,
          nextRoundStart: novaSala.nextRoundStart || null,
          musicStartTimestamp: novaSala.musicStartTimestamp || null,
        });
      });
    }
  }, [isSalaInfoReady]);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [currentSongIndex, musicEnded]);

  useEffect(() => {
    if (fromRanking) {
      // Remove o playerId do localStorage para garantir novo registro
      if (nickname) {
        localStorage.removeItem('playerId_' + nickname);
      }
    }
  }, [fromRanking, nickname]);

  useEffect(() => {

  }, []);

  const normalize = (text) => {
    return text
      .normalize('NFD') // separa acentos
      .replace(/&/g, ' e ') // substitui & por ' e '
      .replace(/\s{2,}/g, ' ') // remove espaços duplos gerados
      .replace(/[-]/g, '') // remove traços
      .replace(/[\u0300-\u036F]/g, '') // remove marcas de acento
      .replace(/[^a-zA-Z0-9\se]/g, '') // remove pontuação e caracteres especiais, mas mantém 'e'
      .toLowerCase()
      .trim();
  };

  // Proteção extra para currentMusic
  const currentMusic = (Array.isArray(shuffledMusics) && shuffledMusics.length > currentSongIndex && currentSongIndex >= 0)
    ? shuffledMusics[currentSongIndex]
    : null;



  const musicStartTimestamp = salaInfo?.musicStartTimestamp || null;

  const [gamificationMsg, setGamificationMsg] = useState('');
  const [showGamification, setShowGamification] = useState(false);
  const [gamificationTime, setGamificationTime] = useState(0);

  function triggerGamification(timeLeft) {
    setGamificationTime(timeLeft);
    setShowGamification(true);
    // Explode confetti real só nos primeiros 10s
    if (timeLeft >= 10) {
      import('canvas-confetti').then(({ default: confetti }) => {
        confetti({
          particleCount: 120,
          spread: 90,
          origin: { y: 0.6 }
        });
      });
    }
  }

  // Handler de resposta do usuário
  const handleAnswer = () => {
    if (!answered && currentMusic) {
      const answer = normalize(input);
      const title = normalize(currentMusic.title.replace(/-/g, ' '));
      const artist = normalize(currentMusic.artist.name.replace(/-/g, ' '));
      setAttempts(prev => [...prev, input]); // Salva tentativa original
      // Correto se resposta contém título E artista (em qualquer ordem)
      const hasTitle = answer.includes(title);
      const hasArtist = answer.includes(artist);
      const hasBoth = hasTitle && hasArtist;
      // Ordem invertida: artista antes do título também é aceita
      const hasBothInverted = (answer.indexOf(artist) > -1 && answer.indexOf(title) > -1);
      if ((hasTitle && hasArtist) || hasBothInverted) {
        setFeedback('✅ Correto!');
        addPoints(currentTimeLeft);
        setAnswered(true);
        triggerGamification(currentTimeLeft);
      } else if (
        hasTitle || hasArtist ||
        title.split(' ').some(word => answer.includes(word)) ||
        artist.split(' ').some(word => answer.includes(word))
      ) {
        setFeedback('✨ Quase lá! Você acertou parte!');
        setInput('');
      } else {
        setFeedback('❌ Errou!');
      }
    }
  };

  const handleTimeUp = (time) => {
    if (hasHandledTimeUp.current) {
      return;
    }
    hasHandledTimeUp.current = true;

    setCurrentTimeLeft(time);
    setMusicEnded(true);

    if (currentMusic) {
      const artistName = currentMusic.artist?.name || 'Artista desconhecido';
      setFeedback(`⏰ Tempo esgotado! A música era "${currentMusic.title.replace(/-/g, ' ')}" por ${currentMusic.artist?.name.replace(/-/g, ' ')}`);
      setTimeout(() => {
        setFeedback('');
        moveToNext();
      }, 2000);
    } else {
      moveToNext();
    }
  };

  const moveToNext = async () => {
    if (currentSongIndex + 1 < shuffledMusics.length) {
      await avancarMusica(currentSongIndex + 1);
      setInput('');
      setFeedback('');
      setAnswered(false); // Garante input destravado
      setCurrentTimeLeft(20);
      setMusicEnded(false);
      hasHandledTimeUp.current = false;
    } else if (currentSongIndex + 1 >= 15) { // Só redireciona se todas as 15 músicas foram tocadas
      // Atualiza musicaAtual para playlist.length para disparar o efeito de reinício
      await avancarMusica(shuffledMusics.length);
      setTimeout(() => {
        navigate('/result', { replace: true });
      }, 4000);
    }
  };

  const handleExit = () => {
    if (window.confirm('Tem certeza que deseja sair da sala?')) {
      resetGame && resetGame();
      navigate('/');
    }
  };

  const previousSongs = shuffledMusics.slice(0, currentSongIndex);

  // Botão de admin para terminar partida instantaneamente
  async function handleTerminarPartida() {
    if (!salaInfo || !salaInfo.playlist) return;
    // Em vez de finalizar a partida, pula para a música 15 (índice 14)
    await avancarMusica(14); // 14 = 15ª música (índice começa em 0)
  }

  const roundId = salaInfo?.musicStartTimestamp || null;
  const { ranking, playerKey, registerPlayerInRanking } = useFirebaseRanking(roundId);

  // Registra jogador no ranking ao entrar na sala (nickname e pontos zerados)
  useEffect(() => {
    // Só registra se nickname.name existir e playerKey estiver definido
    const nickNameStr = typeof nickname === 'object' && nickname !== null ? nickname.name : nickname;
    if (nickNameStr && playerKey && registerPlayerInRanking) {
      registerPlayerInRanking(points ?? 0);
      localStorage.setItem('entrouNaRodada', 'true');
    }
    // eslint-disable-next-line
  }, [nickname, playerKey, points]);

  // Garante sumiço automático após X segundos
  function handleGamificationClose() {
    setShowGamification(false);
  }

  // Novo: input só fica desabilitado se não houver música OU preview OU se já respondeu/tempo acabou (exceto se tempo restante >= 1)
  const isInputDisabled = !currentMusic || !currentMusic.preview || answered || (musicEnded === true && currentTimeLeft < 1);

  return (
    <div className="game-page dark-mode">
      {/* Grid principal */}
      <div className="game-grid dark-mode">
        {/* Coluna da esquerda - Ranking */}
        <div className="ranking-column dark-mode">
          {nickname && <LiveRanking playerKey={playerKey} refreshTrigger={refreshRankingTrigger} />}
        </div>

        {/* Coluna central - Área principal do jogo */}
        <div className="game-column dark-mode">
          <div className="game-card dark-mode">
            <button
              className="exit-button"
              onClick={handleExit}
            >
              Sair da sala
            </button>

            {/* Botão ADMIN: Terminar Partida Instantaneamente */}
            <button
              className="login-btn"
              style={{ marginTop: 16, background: '#f87171', color: '#fff' }}
              onClick={handleTerminarPartida}
            >
              ⚡ Terminar Partida (admin)
            </button>

            <div className="game-header dark-mode">
              <h2>
                {salaInfo && salaInfo.musicaAtual >= salaInfo.playlist.length
                  ? 'Rodada finalizada!'
                  : `🎶 Música ${currentSongIndex + 1} de ${shuffledMusics.length}`}
              </h2>
            </div>

            <div className="player-info dark-mode">
              Jogador: <span>{displayAvatar} {displayName}</span>
            </div>
            <div className="points small-points dark-mode">
              Pontos: {points === null ? <span style={{color:'#fbbf24'}}>Carregando...</span> : points}
            </div>

            <div className="game-controls dark-mode">
              {/* Sempre renderize o MusicPlayer, controlando apenas as props */}
              <MusicPlayer
                musicUrl={currentMusic?.preview || null}
                onTimeUp={handleTimeUp}
                onTimeUpdate={setCurrentTimeLeft}
                isMuted={isMuted}
                setIsMuted={setIsMuted}
                showMuteButtonOnTop
                musicaAtual={salaInfo?.musicaAtual || currentSongIndex || 0}
                musicStartTimestamp={salaInfo?.musicStartTimestamp || null}
              />

              <div className="input-with-enter">
                <input
                  ref={inputRef}
                  className={`answer-input dark-mode ${feedback.includes('Correto') ? 'input-correct' : feedback.includes('Quase') ? 'input-almost' : feedback.includes('Errou') ? 'input-wrong' : ''}`}
                  type="text"
                  placeholder="Digite sua resposta"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') handleAnswer();
                  }}
                  onPaste={e => e.preventDefault()} // Impede colar
                  disabled={isInputDisabled}
                  autoFocus
                  autoCapitalize="off"
                  autoCorrect="off"
                  spellCheck={false}
                  aria-label="Resposta da música"
                  style={{ fontFamily: 'inherit', fontWeight: 600, letterSpacing: 0.01, outline: 0, borderWidth: 2, borderColor: feedback.includes('Correto') ? '#16a34a' : feedback.includes('Quase') ? '#facc15' : feedback.includes('Errou') ? '#ef4444' : '#64748B', background: isInputDisabled ? 'rgba(15,23,42,0.1)' : 'rgba(15,23,42,0.3)', color: '#E2E8F0', minHeight: 44 }}
                />
                <button
                  className="enter-icon"
                  title="Enviar resposta"
                  tabIndex={-1}
                  aria-hidden="true"
                  type="button"
                  style={{ background: 'none', border: 'none', outline: 'none', cursor: isInputDisabled ? 'not-allowed' : 'pointer', position: 'absolute', right: '0.7em', top: '50%', transform: 'translateY(-50%)', height: '2.1em', display: 'flex', alignItems: 'center', zIndex: 2, pointerEvents: isInputDisabled ? 'none' : 'auto' }}
                  onMouseDown={e => { e.preventDefault(); if (!isInputDisabled) handleAnswer(); }}
                  disabled={isInputDisabled}
                >
                  <span className="enter-underline">Enter</span>
                </button>
              </div>
              {attempts.length > 0 && (
                <div className="attempt-history" style={{marginTop: 8, fontSize: '0.97em', color: '#a78bfa', minHeight: 18}}>
                  <span style={{fontWeight: 600}}>Tentativas:</span> {attempts.map((a, i) => <span key={i} style={{marginLeft: 4, marginRight: 4, color: '#fff', background: '#334155', borderRadius: 4, padding: '1px 7px', fontWeight: 500}}>{a}</span>)}
                </div>
              )}
            </div>

            {feedback && (
              <div className={`feedback dark-mode ${
                feedback.includes('Correto') ? 'correct' :
                feedback.includes('Quase') ? 'almost' : 'wrong'
              }`}>
                {feedback}
              </div>
            )}

            {/* --- Gamificação visual --- */}
            {showGamification && (
              <GamificationEffect
                show={showGamification}
                timeLeft={gamificationTime}
                onClose={handleGamificationClose}
              />
            )}

            {currentSongIndex === shuffledMusics.length - 1 && musicEnded && (
              <button
                onClick={() => navigate('/result', { replace: true })}
                className="exit-button dark-mode"
              >
                Ver Resultado Final
              </button>
            )}
          </div>
        </div>

        {/* Coluna da direita - Histórico */}
        <div className="history-column dark-mode">
          <div className="history-card dark-mode">
            <h3>🎵 Músicas Anteriores</h3>
            <PreviousSongsList songs={previousSongs} />
          </div>
        </div>
      </div>

      {roundEnded && (
        <div className="round-end-popup">
          <h2>Rodada Finalizada!</h2>
          <p>Aguarde enquanto redirecionamos para o ranking final...</p>
        </div>
      )}
    </div>
  );
}
