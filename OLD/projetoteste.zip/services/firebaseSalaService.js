import { ref, get, set, update, onValue } from 'firebase/database';
import { db } from './firebase';

const SALA_REF = ref(db, 'salaAtual');

// Tempo de delay real (ex: 10s) entre rodadas
export const DELAY_ENTRE_RODADAS = 20000; // 20 segundos

// Função utilitária para embaralhar array
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// --- PATCH: Nunca permita nextRoundStart no passado ---
function getNextRoundStartFuturo(sugestaoTimestamp = null) {
  const now = Date.now();
  if (!sugestaoTimestamp || sugestaoTimestamp < now + 5000) {
    // Sempre agende para pelo menos 20s à frente
    return now + DELAY_ENTRE_RODADAS;
  }
  return sugestaoTimestamp;
}

// Ajuste: ao INICIAR uma nova rodada, já define nextRoundStart para o tempo total da rodada + delay
export async function iniciarSalaSeNaoExistir(playlist) {
  const snapshot = await get(SALA_REF);
  if (!snapshot.exists()) {
    // Use sempre o array completo da playlist da API
    // Evita repetição de músicas: recupera últimas músicas usadas, se houver
    let ultimaPlaylist = [];
    try {
      const salaSnap = await get(SALA_REF);
      if (salaSnap.exists() && salaSnap.val().playlist) {
        ultimaPlaylist = salaSnap.val().playlist.map(m => m.id);
      }
    } catch {}
    // Filtra para não repetir músicas da rodada anterior
    const shuffled = shuffleArray([...playlist]);
    const validTracks = shuffled.filter(track => track.preview && !ultimaPlaylist.includes(track.id));
    let finalTracks = validTracks.slice(0, 15);
    // Se faltarem músicas, completa com o restante
    if (finalTracks.length < 15) {
      const restantes = shuffled.filter(track => track.preview && finalTracks.findIndex(m => m.id === track.id) === -1);
      finalTracks = finalTracks.concat(restantes.slice(0, 15 - finalTracks.length));
    }
    const now = Date.now();
    const ROUND_DURATION_MS = finalTracks.length * 20 * 1000; // 20s por música
    const nextRoundStart = getNextRoundStartFuturo(now + ROUND_DURATION_MS + DELAY_ENTRE_RODADAS);
    await set(SALA_REF, {
      playlist: finalTracks,
      musicaAtual: 0,
      nextRoundStart,
      musicStartTimestamp: null,
      ultimaPlaylist: finalTracks.map(m => m.id) // salva ids das últimas músicas
    });
  }
}

export async function getSalaAtual() {
  const snapshot = await get(SALA_REF);
  return snapshot.val();
}

export function ouvirSala(callback) {
  return onValue(SALA_REF, (snapshot) => {
    const sala = snapshot.val();
    if (sala) {
      callback(sala);
    }
  });
}

// Ajuste: ao avançar para a primeira música de uma nova rodada, calcula nextRoundStart corretamente
export async function avancarMusica(indice) {
  const salaSnap = await get(SALA_REF);
  if (!salaSnap) return;
  const sala = salaSnap.val();
  if (indice > sala.playlist.length) {
    return;
  }
  const updates = { musicaAtual: indice };
  if (indice === 0) {
    // Nova rodada: calcula nextRoundStart para o tempo total da rodada + delay
    const ROUND_DURATION_MS = sala.playlist.length * 20 * 1000;
    // Só o backend automático deve iniciar a música. Aqui deixamos como null.
    updates.musicStartTimestamp = null;
    updates.nextRoundStart = getNextRoundStartFuturo(Date.now() + ROUND_DURATION_MS + DELAY_ENTRE_RODADAS);
  } else if (indice < sala.playlist.length) {
    // Só atualiza musicStartTimestamp se musicaAtual realmente mudou ou se o timestamp está nulo
    if (sala.musicaAtual !== indice || !sala.musicStartTimestamp) {
      updates.musicStartTimestamp = Date.now() + 500; // Adiciona 0.5s para compensar atraso de propagação
    } else {
      // Não atualiza para evitar múltiplos resets
      updates.musicStartTimestamp = sala.musicStartTimestamp;
    }
    // NÃO atualize nextRoundStart durante a execução das músicas!
    // updates.nextRoundStart = getNextRoundStartFuturo(sala.nextRoundStart);
  } else {
    // Fim da rodada: agenda próximo round para daqui a DELAY_ENTRE_RODADAS
    updates.musicStartTimestamp = null;
    updates.nextRoundStart = getNextRoundStartFuturo(Date.now() + DELAY_ENTRE_RODADAS);
  }
  await update(SALA_REF, updates);
}

// --- PATCH: Nunca remova nextRoundStart ao reiniciar sala, sempre set válido ---
export async function reiniciarSala(playlist) {
  // Evita repetição de músicas: recupera últimas músicas usadas, se houver
  let ultimaPlaylist = [];
  try {
    const salaSnap = await get(SALA_REF);
    if (salaSnap.exists() && salaSnap.val().playlist) {
      ultimaPlaylist = salaSnap.val().playlist.map(m => m.id);
    }
  } catch {}
  // Filtra para não repetir músicas da rodada anterior
  const shuffled = shuffleArray([...playlist]);
  const validTracks = shuffled.filter(track => track.preview && !ultimaPlaylist.includes(track.id));
  let finalTracks = validTracks.slice(0, 15);
  // Se faltarem músicas, completa com o restante
  if (finalTracks.length < 15) {
    const restantes = shuffled.filter(track => track.preview && finalTracks.findIndex(m => m.id === track.id) === -1);
    finalTracks = finalTracks.concat(restantes.slice(0, 15 - finalTracks.length));
  }
  const now = Date.now();
  // O próximo round começa após a duração da rodada + delay
  const ROUND_DURATION_MS = finalTracks.length * 20 * 1000; // 20s por música
  const nextRoundStart = getNextRoundStartFuturo(now + ROUND_DURATION_MS + DELAY_ENTRE_RODADAS);
  await update(SALA_REF, {
    playlist: finalTracks,
    musicaAtual: 0,
    nextRoundStart,
    musicStartTimestamp: null,
    ultimaPlaylist: finalTracks.map(m => m.id)
  });
}

export async function reiniciarSalaComLoop(playlist) {
  // Evita repetição de músicas: recupera últimas músicas usadas, se houver
  let ultimaPlaylist = [];
  try {
    const salaSnap = await get(SALA_REF);
    if (salaSnap.exists() && salaSnap.val().playlist) {
      ultimaPlaylist = salaSnap.val().playlist.map(m => m.id);
    }
  } catch {}
  // Filtra para não repetir músicas da rodada anterior
  const shuffled = shuffleArray([...playlist]);
  const validTracks = shuffled.filter(track => track.preview && !ultimaPlaylist.includes(track.id));
  let finalTracks = validTracks.slice(0, 15);
  // Se faltarem músicas, completa com o restante
  if (finalTracks.length < 15) {
    const restantes = shuffled.filter(track => track.preview && finalTracks.findIndex(m => m.id === track.id) === -1);
    finalTracks = finalTracks.concat(restantes.slice(0, 15 - finalTracks.length));
  }
  const now = Date.now();
  // Corrigido: calcula tempo total da rodada + delay
  const ROUND_DURATION_MS = finalTracks.length * 20 * 1000; // 20s por música
  const nextRoundStart = getNextRoundStartFuturo(now + ROUND_DURATION_MS + DELAY_ENTRE_RODADAS);
  await update(SALA_REF, {
    playlist: finalTracks,
    musicaAtual: 0,
    nextRoundStart,
    musicStartTimestamp: null,
    ultimaPlaylist: finalTracks.map(m => m.id)
  });
}

export async function setNextRoundStart(timestamp) {
  await update(SALA_REF, { nextRoundStart: getNextRoundStartFuturo(timestamp) });
}

export async function liberarLockReinicioRodada() {
  const lockRef = ref(db, 'rodadaReiniciando');
  await set(lockRef, null);
}

// Tenta adquirir o lock para reiniciar a rodada
export async function tentarLockReinicioRodada(timeoutMs = 3000) {
  const lockRef = ref(db, 'rodadaReiniciando');
  const now = Date.now();
  try {
    const snapshot = await get(lockRef);
    if (snapshot.exists()) {
      const data = snapshot.val();
      if (now - data.timestamp > timeoutMs) {
        await set(lockRef, { timestamp: now });
        return true;
      }
      return false;
    } else {
      await set(lockRef, { timestamp: now });
      return true;
    }
  } catch  {
    return false;
  }
}

export async function atualizarTempoRestante() {
  const sala = await getSalaAtual();
  if (!sala || !sala.nextRoundStart) return;
  const now = Date.now();
  const timeLeft = Math.max(0, Math.ceil((sala.nextRoundStart - now) / 1000));
  await update(SALA_REF, { timeLeftToNextRound: timeLeft });
}

// --- PATCH: Garante nextRoundStart válido sempre que a sala for criada ou reiniciada ---
export async function garantirNextRoundStartValido() {
  const salaSnap = await get(SALA_REF);
  const sala = salaSnap.val();
  const now = Date.now();
  // Se nextRoundStart está ausente ou no passado, agenda para daqui a 3 minutos
  if (!sala || !sala.nextRoundStart || sala.nextRoundStart < now) {
    const valor = now + 3 * 60 * 1000; // 3 minutos no futuro

    await update(SALA_REF, {
      nextRoundStart: valor
    });
  }
}
